/* Deterministic frame renderer. Requires Chromium + FFmpeg, no external asset services. */
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawn}=require('node:child_process');
const { chromium }=require('playwright');
const { createProjectServer }=require('./server.cjs');
const ROOT=__dirname;
const sandbox={window:{}};vm.runInNewContext(fs.readFileSync(path.join(ROOT,'config.js'),'utf8'),sandbox);const cfg=sandbox.window.FILM;
const arg=process.argv.slice(2),preview=arg.includes('--stills');
function mediaFile(value){if(!value)return null;const p=path.resolve(ROOT,value);if(!p.startsWith(ROOT+path.sep))throw Error('Media paths must be inside the project.');if(!fs.existsSync(p))throw Error('Missing media: '+value);return p;}
const server=createProjectServer(ROOT);
(async()=>{let browser,encoder;try{
 for(const p of Object.values(cfg.media))mediaFile(p);
 if(cfg.width!==1920||cfg.height!==1080||cfg.fps!==30||cfg.duration!==75)throw Error('Delivery format changed; expected 1920x1080 / 30fps / 75s.');
 fs.mkdirSync(path.join(ROOT,'output'),{recursive:true});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const executablePath=process.env.CHROMIUM_PATH||['/usr/bin/chromium','/usr/bin/chromium-browser','/usr/bin/google-chrome'].find(fs.existsSync);
 browser=await chromium.launch({...(executablePath?{executablePath}:{}),headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const page=await browser.newPage({viewport:{width:1920,height:1080},deviceScaleFactor:1});
 page.on('pageerror',err=>{throw err});await page.goto(`http://127.0.0.1:${server.address().port}/render.html`);await page.evaluate(()=>window.renderReady);
 if(preview){for(let i=0;i<cfg.scenes.length;i++){const s=cfg.scenes[i],t=s.start+Math.min(1.4,(s.end-s.start)/2);await page.evaluate(t=>prepareFrame(t),t);await page.locator('canvas').screenshot({path:path.join(ROOT,`output/still-${String(i).padStart(2,'0')}.png`)});console.log(`Still ${i+1}: ${s.type} / ${t}s`)}return;}
 const inputs=['-f','image2pipe','-vcodec','mjpeg','-framerate',String(cfg.fps),'-i','pipe:0'];let count=0;const music=mediaFile(cfg.media.music),voice=mediaFile(cfg.media.voiceover);
 if(music){inputs.push('-i',music);count++}if(voice){inputs.push('-i',voice);count++}
 let audio=[];if(count===2)audio=['-filter_complex','[1:a]volume=0.45[m];[m][2:a]amix=inputs=2:duration=longest:normalize=0,alimiter=limit=0.95[a]','-map','0:v:0','-map','[a]'];else if(count)audio=['-map','0:v:0','-map','1:a:0'];
 const output=path.join(ROOT,'output/final-final-studio.mp4');const log=fs.openSync(path.join(ROOT,'output/render.log'),'w');
 encoder=spawn('ffmpeg',['-hide_banner','-y',...inputs,...audio,'-c:v','libx264','-preset','fast','-crf','18','-vf','scale=in_range=full:out_range=tv:in_color_matrix=bt601:out_color_matrix=bt709,format=yuv420p','-pix_fmt','yuv420p','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-bsf:v','h264_metadata=colour_primaries=1:transfer_characteristics=1:matrix_coefficients=1:video_full_range_flag=0',...(count?['-c:a','aac','-b:a','256k','-ar','48000']:[]),'-r',String(cfg.fps),'-t',String(cfg.duration),'-movflags','+faststart',output],{stdio:['pipe','ignore',log]});
 let encoderError;encoder.on('error',e=>encoderError=e);encoder.stdin.on('error',e=>encoderError=e);const finished=new Promise((resolve,reject)=>encoder.on('close',code=>code===0?resolve():reject(Error('FFmpeg exited '+code+'; inspect output/render.log'))));finished.catch(()=>{});
 const total=cfg.duration*cfg.fps,begin=Date.now();for(let f=0;f<total;f++){
 if(encoderError)throw encoderError;
 const jpg=await page.evaluate(async t=>{await window.prepareFrame(t);return document.getElementById('film').toDataURL('image/jpeg',.96).split(',')[1]},f/cfg.fps);
 if(!encoder.stdin.write(Buffer.from(jpg,'base64')))await new Promise((resolve,reject)=>{const done=()=>{encoder.stdin.off('error',fail);resolve()};const fail=e=>{encoder.stdin.off('drain',done);reject(e)};encoder.stdin.once('drain',done);encoder.stdin.once('error',fail)});
 if(f%150===0)console.log(`${f}/${total} frames · ${(f/30).toFixed(1)}s of film · ${((Date.now()-begin)/1000).toFixed(0)}s elapsed`);
 }
 encoder.stdin.end();await finished;fs.closeSync(log);console.log('Export complete: '+output);
 }catch(err){console.error(err);process.exitCode=1;if(encoder)encoder.kill('SIGTERM');}finally{if(browser)await browser.close();server.close();}})();
