# Final Final Studio — 75-second motion film

A runnable, editable motion-graphics project for a proposed editing and content studio. The delivery specification is **1920 × 1080, 16:9, 30 fps, exactly 75 seconds / 2,250 frames**. The palette is charcoal `#111111`, off-white `#F5F5F0`, and lime `#C5FF00`.

## 查看 / Preview

From this directory:

```sh
npm start
# Equivalent: node server.cjs
```

Open the served `index.html` in a browser. The included Node server supports HTTP Range requests for accurate seeking in replacement video clips. The player has play/pause, a time scrubber, sound controls, and an editable configuration panel. Browser audio starts only after a user gesture. Use **SOUND ON** to hear the included score.

## 渲染 / Render

The renderer requires Node.js, Playwright, Chromium and FFmpeg. This cloud environment supplies these tools. For another machine, install the exact Playwright version declared in `package.json` with `npm ci --cache /tmp/finalfinal-npm-cache`, then install Chromium using `npx playwright install chromium`. FFmpeg must be available on `PATH`.

```sh
npm run render
# Optional: export all 19 storyboard frames
npm run stills
```

Rendering samples the same editable composition at exactly 30 fps and encodes a standard H.264/AAC MP4 with explicit Rec.709 colour metadata. The resulting film is written to `output/final-final-studio.mp4`. Rendering the full film takes time; keep the process running until encoding completes. The MP4 is the flattened delivery; the project files retain editable text, layouts, colours, and timing.

## 编辑 / Editing

- **`config.js`** is the main edit point (including `copy` for interface and sample campaign text): headline and supporting copy, service descriptions, palette, scene start/end times, media paths, frame rate, and duration. Keep scene intervals contiguous and in chronological order.
- **`film.js`** contains editable vector shapes, typography, masks, interface elements, and animation curves. Graphics are drawn as code, not baked into background images.
- **`index.html`** is the standalone preview player. Its JSON editor applies changes to the preview only. To retain changes, copy the resulting object into `config.js` after `window.FILM =`.
- **`server.cjs`** serves the preview and media with byte-range support.
- **`render.cjs`** produces the final MP4 from the composition. Render again after editing.
- **`assets/Display.ttf`** and **`assets/Mono.ttf`** are local DejaVu Sans Bold and DejaVu Sans Mono fonts. Font licensing and attribution are in `assets/FONT-LICENSE.txt`.

The design keeps essential messaging inside the 5% safe area. Oversized decorative elements may extend beyond it.

## 素材状态 / Asset status

**No supplied product clips, separate storyboard document, or voiceover audio were present in the task or workspace.** Timing therefore follows the written narrative in the brief, rather than an unavailable voiceover or separate storyboard. These materials remain missing; they are not represented as supplied or verified.

The sample campaign uses editable abstract vector placeholders, visibly labelled **Concept work** and **Placeholder**. They demonstrate editing, captions, aspect-ratio adaptations, and matching graphics. They are not client assets or purported product footage. There are no invented client logos, testimonials, performance figures, or contact details.

To replace the product placeholder, put a clip in `assets/` and set `media.product` in `config.js` to its relative path, such as `assets/product.mp4`. To add the intended voiceover, set `media.voiceover`, for example `assets/voiceover.wav`. Keep paths relative to the project root and render again. Review timing against the actual supplied voiceover once available; do not assume that a replacement recording will automatically match the current text timing.

`assets/score.wav` is an **original synthesized instrumental score** created for this project, not a supplied voiceover or licensed commercial track. It is stereo, 48 kHz, PCM16, exactly 75 seconds, with a measured peak of −1.5 dBFS. It uses a 120 BPM electronic pulse, warm synthesis, request-notification accents, and restrained typing sounds around the final rename. No external musical samples or speech are used. Recreate it with:

```sh
python scripts/make_score.py
```

The generator requires NumPy. Set `media.music` to another cleared audio file if desired. Check rights and voice/music balance for replacement media before external publication.

## 时间结构 / Timing

| Time | Sequence |
|---|---|
| 00–14 s | Escalating requests, extra formats, captions, urgent deadline, a breath |
| 14–23 s | Final Final Studio reveal; client brief, brand guidelines, existing materials |
| 23–28 s | Editing and pacing |
| 28–33 s | Caption treatment |
| 33–38 s | 16:9, 1:1, and 9:16 adaptations |
| 38–43 s | Matching social graphics |
| 43–47 s | Campaign assets together |
| 47–55 s | Quick Edit; Campaign Content Pack; Monthly Creative Support |
| 55–61 s | Brief, Review, Deliver |
| 61–66 s | “On brief. On brand. On time.” |
| 66–69 s | Rename `final.mp4` to `final_final.mp4` |
| 69–75 s | Final Final Studio + “Let’s make your next edit.” |

This is concept work for a proposed studio. The current sequence is a complete editable concept film; replacement of the missing supplied media and voiceover requires a subsequent timing review.

## 输出文件 / Deliverables

- `output/final-final-studio.mp4`: 75-second H.264/AAC final concept film.
- `output/contact-sheet.jpg`: visual overview of all 19 scenes.
- `output/validation.json`: measured export properties and asset status.
- `output/final-final-studio-project.zip`: editable project, bundled fonts, original score and sources (excludes node_modules and rendered outputs).

For a new machine: `npm ci --cache /tmp/finalfinal-npm-cache`, install Chromium and FFmpeg if needed, then `npm start` to preview or `npm run render` to export. `CHROMIUM_PATH` can override the system browser path. No external video, font, or audio requests are made during playback or rendering.

## 验证 / Checks

`npm run check` exercises playback, frame scrubbing, editable configuration, local fonts and byte-range media serving. After rendering, `npm run check -- --media` also checks the export format, exact duration and frame count.
