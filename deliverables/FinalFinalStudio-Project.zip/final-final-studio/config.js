window.FILM = {
 width:1920,height:1080,fps:30,duration:75,
 colors:{black:'#111111',white:'#F5F5F0',lime:'#C5FF00'},
 media:{product:null,voiceover:null,music:'assets/score.wav'},
 // Set product to a local video path, e.g. assets/product.mp4. Keep Concept work label.
 scenes:[
 {start:0,end:3,type:'request',headline:'JUST ONE\nQUICK EDIT.',note:'NEW REQUEST',sub:'A familiar beginning.'},
 {start:3,end:6,type:'stack',headline:'AND A\nVERTICAL ONE.',note:'ALSO…',sub:'Same campaign. Another format.'},
 {start:6,end:9,type:'deadline',headline:'CAN WE GET\nCAPTIONS?',note:'ONE MORE THING',sub:'And make it feel on brand.'},
 {start:9,end:12,type:'rush',headline:'NEEDED\nYESTERDAY.',note:'DEADLINE UPDATED',sub:'The brief keeps moving.'},
 {start:12,end:14,type:'pause',headline:'WE GET IT.',note:'TAKE A BREATH',sub:'Let’s get it moving.'},
 {start:14,end:19,type:'brand',headline:'FINAL\nFINAL',note:'MEET YOUR EXTRA PAIR OF HANDS',sub:'STUDIO'},
 {start:19,end:23,type:'inputs',headline:'YOUR INPUT.\nOUR EDIT.',note:'GOOD WORK STARTS HERE',sub:'Brief / Brand guidelines / Existing materials'},
 {start:23,end:28,type:'edit',headline:'FIND\nTHE FLOW.',note:'01 / SHORT-FORM EDITING',sub:'Sharper cuts. A clearer story.'},
 {start:28,end:33,type:'captions',headline:'MAKE EVERY\nWORD LAND.',note:'02 / CAPTIONS',sub:'Readable. Timed. On brand.'},
 {start:33,end:38,type:'ratios',headline:'ONE STORY.\nEVERY FORMAT.',note:'03 / CONTENT ADAPTATION',sub:'16:9 / 1:1 / 9:16'},
 {start:38,end:43,type:'graphics',headline:'LOOKS LIKE\nYOUR BRAND.',note:'04 / SOCIAL GRAPHICS',sub:'Matching graphics. One visual language.'},
 {start:43,end:47,type:'campaign',headline:'READY\nTO ROLL.',note:'THE CAMPAIGN / TOGETHER',sub:'Edit + Captions + Adaptations + Graphics'},
 {start:47,end:55,type:'services',headline:'A LITTLE HELP.\nA LOT OF RANGE.',note:'CHOOSE YOUR SUPPORT',sub:''},
 {start:55,end:57,type:'step',headline:'BRIEF.',note:'01 / THE PROCESS',sub:'Share the goal, guidelines and materials.'},
 {start:57,end:59,type:'step',headline:'REVIEW.',note:'02 / THE PROCESS',sub:'Clear feedback. A focused revision.'},
 {start:59,end:61,type:'step',headline:'DELIVER.',note:'03 / THE PROCESS',sub:'The right files. The right formats.'},
 {start:61,end:66,type:'tagline',headline:'ON BRIEF.\nON BRAND.\nON TIME.',note:'THE WAY WE WORK',sub:'On brief. On brand. On time.'},
 {start:66,end:69,type:'rename',headline:'final.mp4',note:'ONE LAST THING…',sub:'final_final.mp4'},
 {start:69,end:75,type:'end',headline:'FINAL\nFINAL',note:'SHORT-FORM VIDEO / GRAPHICS / ADAPTATION',sub:'Let’s make your next edit.'}
 ],
 copy:{
  studio:'STUDIO',footerBrand:'FINAL FINAL STUDIO',footerEdition:'MOTION / 001',
  incoming:'INCOMING',requestCounter:'01',requestReceived:'REQUEST RECEIVED',requestFooter:'THE CONTENT NEVER STOPS.',
  stackRatios:['16:9','1:1','9:16'],stackIncrement:'+1',stackBadge:'+ FORMAT VERSION',
  captionsIcon:'CC',requestAdds:['+ VIDEO','+ VERTICAL','+ CAPTIONS'],rushPriority:'PRIORITY / RIGHT NOW',
  brandServices:'EDITING / GRAPHICS / CONTENT ADAPTATION',
  inputNames:['BRIEF','BRAND GUIDELINES','EXISTING MATERIALS'],
  inputNotes:['The goal. The audience.','The look. The language.','Your footage. Your assets.'],
  editBadge:'CUT / TRIM / SEQUENCE',sampleWords:['MAKE','IT','MOVE.'],sampleCode:'SAMPLE / 01',
  captionTiming:'WORD-LEVEL TIMING',matchingLabels:['01 / VIDEO','02 / SOCIAL POST','03 / MOTION'],
  campaignBadge:'READY TO ADAPT',taglineFoot:'LESS BACK-AND-FORTH. MORE FORWARD.',
  renameExport:'EXPORT / SAVE AS',renameStatus:'APPROVED FOR THE NEXT CHAPTER',renamePending:'RENAMING…',
  conceptLabel:'CONCEPT WORK',placeholderLabel:'VECTOR PLACEHOLDER',providedLabel:'CLIENT-SUPPLIED CLIP',
  trackNames:['A01','V01'],editTakes:['TAKE 01','TAKE 03','TAKE 05','OUT']
 },
 services:[['Quick Edit','Focused short-form video editing.'],['Campaign Content Pack','Edits, graphics and format adaptations.'],['Monthly Creative Support','Ongoing editing and content support.']]
};
