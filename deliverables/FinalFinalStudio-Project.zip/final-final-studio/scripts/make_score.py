#!/usr/bin/env python3
"""Deterministic original instrumental score; no samples, voices, or external media.
75 seconds, stereo 48 kHz. Requires numpy. Run from any directory.
"""
from pathlib import Path
import wave
import numpy as np

SR = 48000
DURATION = 75
BPM = 120
BEAT = 60 / BPM
RNG = np.random.default_rng(20261026)
OUT = Path(__file__).resolve().parents[1] / 'assets' / 'score.wav'
mix = np.zeros((SR * DURATION, 2), dtype=np.float64)


def add(x, at, amp=1.0, pan=0.0):
    start = round(at * SR)
    if start < 0 or start >= len(mix):
        return
    x = x[:len(mix)-start] * amp
    mix[start:start+len(x), 0] += x * np.sqrt((1-pan)/2)
    mix[start:start+len(x), 1] += x * np.sqrt((1+pan)/2)


def tgrid(seconds):
    return np.arange(round(seconds * SR)) / SR


def midi(n):
    return 440 * 2 ** ((n-69) / 12)


def kick():
    t = tgrid(.43)
    f = 43 + 125*np.exp(-t*37)
    phase = np.cumsum(f) * 2*np.pi / SR
    body = np.sin(phase) * np.exp(-t*13)
    snap = RNG.normal(0, 1, len(t)) * np.exp(-t*400) * .15
    return np.tanh((body+snap)*1.6) * np.minimum(t*1000, 1)


def snare():
    t = tgrid(.22)
    n = RNG.normal(0, 1, len(t))
    smooth = np.convolve(n, np.ones(11)/11, 'same')
    return (smooth*.8*np.exp(-t*24) + np.sin(2*np.pi*177*t)*.15*np.exp(-t*32)) * np.minimum(1, t*1600)


def hat(open_hat=False):
    t=tgrid(.18 if open_hat else .067)
    n=RNG.normal(0,1,len(t))
    n=np.r_[0,np.diff(n)]
    return n*np.exp(-t*(30 if open_hat else 84))*.13*np.minimum(1,t*2200)


def pluck(note, duration=.8, bright=.4):
    t=tgrid(duration)
    f=midi(note)
    env=(1-np.exp(-t*250))*np.exp(-t*5)
    # Warm bell with gently detuned partials, rather than a piercing square.
    return (np.sin(2*np.pi*f*t+.10*np.sin(2*np.pi*f*2*t))*0.7
            +np.sin(2*np.pi*f*2.002*t)*bright*.24
            +np.sin(2*np.pi*f*3*t)*bright*.1)*env


def bass(note,duration=.4):
    t=tgrid(duration); f=midi(note)
    return (np.sin(2*np.pi*f*t)+.22*np.sin(2*np.pi*f*2*t)+.1*np.sin(2*np.pi*f*3*t))*(1-np.exp(-t*140))*np.exp(-t*5)


def pad(notes,duration=3):
    t=tgrid(duration)
    x=np.zeros(len(t))
    for note in notes:
        f=midi(note)
        x += np.sin(2*np.pi*f*t)*.6+np.sin(2*np.pi*(f*1.0015)*t)*.35
    env=np.minimum(1,t/.18)*np.minimum(1,np.maximum(0,(duration-t)/1.3))
    return x/len(notes)*env*.75


def impact(at,amp=.5):
    add(kick(),at,amp)
    t=tgrid(1.25)
    n=RNG.normal(0,1,len(t)); n=np.convolve(n,np.ones(55)/55,'same')
    add(n*np.exp(-t*4),at,.35*amp)
    add(pluck(74,1.4),at,.18*amp,-.35)


# Opening: playful request notifications gather momentum.
for at,n in [(0,74),(3,77),(6,79),(9,81),(10.5,79),(11.25,77),(12,74)]:
    add(pluck(n,.65),at,.19, -.35 if at % 2 else .35)
    add(pluck(n-12,.8),at+.11,.08, .35)
for at in np.arange(.5,12,.5):
    add(hat(),float(at),.18, .25 if int(at*2)%2 else -.25)
for at in [0,3,6,9,10,11]:
    add(bass(38,.7),at,.33)
    add(kick(),at,.32)
# Brief pause before brand reveal; airy reverse swell, not a glitch.
t=tgrid(1.3)
n=RNG.normal(0,1,len(t)); n=np.convolve(n,np.ones(130)/130,'same')
add(n*(t/1.3)**2,12.7,.45)

# Main arrangement: rounded, punchy electronic house pulse; 120 BPM.
# Dm9 / Fmaj7 / Am7 / G6, with no sampled material.
chords=[[50,57,60,64,69],[53,57,60,64,67],[45,52,55,60,64],[43,50,55,59,64]]
roots=[38,41,33,31]
for b in range(28,132):
    at=b*BEAT
    if at >= 66: break
    bar=(b-28)//8
    chord=chords[bar%4]
    root=roots[bar%4]
    energy=.80 if at<23 else (1.0 if at<47 else .57 if at<55 else .70)
    # Four-on-the-floor anchors the pacing without dominating typography.
    if not(54.5 <= at < 55):
        add(kick(),at,.48*energy)
    if b%2==1:
        add(snare(),at,.66*energy)
    add(hat(),at+.25,.46*energy, .25)
    if 23<=at<47 and b%2==0:
        add(hat(True),at+.375,.27,-.3)
    # Syncopated bass melody.
    if b%4 in [0,2,3]:
        add(bass(root if b%4!=3 else root+12,.42),at,.35*energy)
    if b%8==0:
        add(pad(chord,4.6),at,.19*energy,-.12)
        add(pad([n+12 for n in chord],4.6),at+.07,.055*energy,.35)
    # Sparse, percussive melodic motif with ping-pong echoes.
    if b%2==0 or 23<=at<47:
        note=chord[[(b-28)%8//2,2,3,1][(b//2)%4] % len(chord)]+12
        vol=.125*energy
        add(pluck(note,.85),at+.125,vol, -.35 if b%4 else .35)
        add(pluck(note,.8),at+.5,vol*.24, .4 if b%4 else -.4)
        add(pluck(note,.8),at+.875,vol*.10)
for at in [14,23,33,43,47,55,61]:
    impact(at,.44 if at!=14 else .66)

# Workflow steps get subtle keyed clicks; file rename has intentional space.
for at in [55,57,59,61]:
    add(pluck(74,.6),at,.18,-.2)
for at in np.arange(66.15,68.5,.135):
    x=RNG.normal(0,1,1050)*np.exp(-np.arange(1050)/135)
    add(x,float(at),.028, float(RNG.uniform(-.3,.3)))
add(pluck(81,.7),68.55,.17,.2)
add(pluck(86,.8),68.68,.09,-.2)
# Long final brand resolution, no music abruptly cut at 75.
impact(69,.5)
add(pad([50,57,60,64,69],5.7),69,.26,-.2)
add(pad([62,69,72,76],5.4),69.25,.1,.25)
for at,n in [(69,74),(69.5,77),(70,81),(70.5,86)]:
    add(pluck(n,2.7),at,.14,(-.3 if n%2 else .3))
    add(pluck(n,2.5),at+.375,.05, .4)

# Gentle master shaping, DC removal, short head/tail fades, and safe headroom.
mix -= mix.mean(axis=0)
mix=np.tanh(mix*1.2)
peak=float(np.max(np.abs(mix)))
mix *= (10**(-1.5/20))/max(peak,1e-9)
fade_in=np.linspace(0,1,int(.015*SR))
fade_out=np.linspace(1,0,int(1.25*SR))**1.4
mix[:len(fade_in)]*=fade_in[:,None]
mix[-len(fade_out):]*=fade_out[:,None]
OUT.parent.mkdir(parents=True,exist_ok=True)
with wave.open(str(OUT),'wb') as f:
    f.setnchannels(2);f.setsampwidth(2);f.setframerate(SR)
    f.writeframes(np.round(np.clip(mix,-1,1)*32767).astype('<i2').tobytes())
print(f'{OUT}: {DURATION}s, stereo {SR}Hz PCM16, peak {20*np.log10(abs(mix).max()):.2f} dBFS')
