#!/usr/bin/env python3
"""Validate the completed render and package local delivery files.

Run after ``npm run render``. This script makes files in the local cloud
workspace; it does not upload them or establish that chat downloads work.
Requires Python 3, ffprobe and ffmpeg; uses no third-party Python packages.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
from datetime import datetime, timezone
import zipfile

ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "output"
MOVIE = OUTPUT / "final-final-studio.mp4"
ARCHIVE = OUTPUT / "final-final-studio-project.zip"
REPORT = OUTPUT / "validation.json"
DOWNLOADS = ROOT.parent / "downloads"

DEFAULT_ASSETS = {
    "product_clips": "Not supplied; editable vector placeholder labelled Concept work",
    "storyboard": "Not supplied; written narrative used as timing reference",
    "voiceover": "Not supplied; no speech synthesized",
    "score": "Original 75-second instrumental score included",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def source_files():
    excluded = {".git", "node_modules", "output", "__pycache__", ".pytest_cache"}
    for base, dirs, files in os.walk(ROOT):
        dirs[:] = sorted(d for d in dirs if d not in excluded)
        for name in sorted(files):
            if name.startswith((".qa-", ".test-")) or name.endswith((".pyc", ".tmp", ".log")):
                continue
            path = Path(base) / name
            # Do not accidentally include external content via a linked file.
            require(not path.is_symlink(), f"Review linked source before packaging: {path}")
            if path.is_file():
                yield path


def readable_copy(source: Path, destination: Path) -> None:
    shutil.copyfile(source, destination)
    destination.chmod(0o644)
    require(sha256(source) == sha256(destination), f"Copy checksum mismatch: {destination}")


def main() -> None:
    require(MOVIE.is_file() and MOVIE.stat().st_size > 0, "No completed render; run npm run render first.")
    probe = json.loads(subprocess.check_output([
        "ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(MOVIE)
    ], text=True))
    videos = [s for s in probe["streams"] if s.get("codec_type") == "video"]
    audios = [s for s in probe["streams"] if s.get("codec_type") == "audio"]
    require(len(videos) == 1 and len(audios) == 1, "Expected exactly one video and one audio stream.")
    video, audio = videos[0], audios[0]
    require(video.get("codec_name") == "h264", "Video must be H.264.")
    require(audio.get("codec_name") == "aac", "Audio must be AAC.")
    require((video.get("width"), video.get("height")) == (1920, 1080), "Video must be 1920 x 1080.")
    require(video.get("r_frame_rate") == "30/1", "Video must be 30 fps.")
    require(int(video.get("nb_frames", 0)) == 2250, "Video must contain exactly 2,250 frames.")
    require(abs(float(probe["format"]["duration"]) - 75) < 0.00001, "Container duration must be exactly 75 seconds.")
    require(abs(float(video.get("duration", 0)) - 75) < 0.00001, "Video duration must be exactly 75 seconds.")
    require(abs(float(audio.get("duration", 0)) - 75) < 0.00001, "Audio duration must be exactly 75 seconds.")
    subprocess.run(["ffmpeg", "-v", "error", "-i", str(MOVIE), "-f", "null", "-"], check=True)

    prior = {}
    if REPORT.is_file():
        try:
            prior = json.loads(REPORT.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    assets = prior.get("assets", DEFAULT_ASSETS)
    if not isinstance(assets, dict):
        assets = DEFAULT_ASSETS
    generated_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    report = {
        "delivery": "Final Final Studio / 75-second concept film",
        "generated_at_utc": generated_at,
        "render_modified_at_utc": datetime.fromtimestamp(MOVIE.stat().st_mtime, timezone.utc).isoformat(timespec="seconds"),
        "video": {k: video.get(k) for k in ["codec_name", "width", "height", "r_frame_rate", "nb_frames", "pix_fmt", "color_space", "color_primaries", "color_transfer", "color_range"]},
        "audio": {k: audio.get(k) for k in ["codec_name", "sample_rate", "channels", "duration"]},
        "duration_seconds": 75,
        "full_decode": "passed",
        "sha256": sha256(MOVIE),
        "checks_this_run": ["H.264/AAC stream formats", "1920 x 1080 dimensions", "30 fps / 2,250 frames", "75-second video, audio and container", "Full FFmpeg decode", "Delivery copy checksums", "ZIP integrity"],
        "assets": assets,
        "scene_count": prior.get("scene_count", 19),
        "editable_project": "HTML/JavaScript Canvas; typography and interface are live type and vector primitives",
        "download_status": "Local files only. No upload performed; chat attachment download availability is not established by packaging.",
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    REPORT.chmod(0o644)

    fd, temporary_name = tempfile.mkstemp(prefix="delivery-", suffix=".zip", dir=OUTPUT)
    os.close(fd)
    temporary = Path(temporary_name)
    try:
        count = 0
        with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for source in source_files():
                archive.write(source, Path("final-final-studio") / source.relative_to(ROOT))
                count += 1
        with zipfile.ZipFile(temporary) as archive:
            require(archive.testzip() is None, "Project ZIP integrity check failed.")
        temporary.replace(ARCHIVE)
    finally:
        temporary.unlink(missing_ok=True)
    ARCHIVE.chmod(0o644)

    DOWNLOADS.mkdir(mode=0o755, exist_ok=True)
    DOWNLOADS.chmod(0o755)
    deliveries = [(MOVIE, "FinalFinalStudio.mp4"), (ARCHIVE, "FinalFinalStudio-Project.zip"), (REPORT, "FinalFinalStudio-Validation.json")]
    storyboard = OUTPUT / "contact-sheet.jpg"
    if storyboard.is_file():
        deliveries.append((storyboard, "FinalFinalStudio-Storyboard.jpg"))
    for source, name in deliveries:
        destination = DOWNLOADS / name
        readable_copy(source, destination)
        print(f"Verified local file: {destination} ({destination.stat().st_size:,} bytes)")
    print(f"Packaged {count} project files; validated at {generated_at}.")
    print("No files were uploaded; these paths are local cloud-workspace files.")


if __name__ == "__main__":
    main()
