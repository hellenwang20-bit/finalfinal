/* Focused preview smoke checks. Optional --media validates the current MP4 delivery. */
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {execFileSync}=require('node:child_process');
const {chromium}=require('playwright');
const {createProjectServer}=require('../server.cjs');
const root=path.resolve(__dirname,'..');

(async()=>{
 const server=createProjectServer(root);let browser;
 try{
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)});
  const origin=`http://127.0.0.1:${server.address().port}`;
  const ranged=await fetch(`${origin}/assets/score.wav`,{headers:{Range:'bytes=0-31'}});
  assert.equal(ranged.status,206,'Audio request must support HTTP Range');
  assert.equal((await ranged.arrayBuffer()).byteLength,32,'Range must return exactly32 bytes');
  assert.match(ranged.headers.get('content-range'),/^bytes 0-31\/\d+$/);
  console.log('PASS: media server returns206 /32 bytes for requested audio range');

  const executablePath=process.env.CHROMIUM_PATH||['/usr/bin/chromium','/usr/bin/chromium-browser','/usr/bin/google-chrome'].find(fs.existsSync);
  browser=await chromium.launch({...(executablePath?{executablePath}:{}),headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
  const page=await browser.newPage({viewport:{width:1440,height:1080}});
  const errors=[];page.on('pageerror',error=>errors.push(error.message));
  await page.goto(`${origin}/index.html`);
  await page.evaluate(()=>document.fonts.ready);
  await page.waitForFunction(()=>typeof window.previewFrame==='function'&&document.fonts.check('30px Display')&&document.fonts.check('30px Mono'));
  const data=await page.evaluate(()=>({width:document.querySelector('canvas').width,height:document.querySelector('canvas').height,scenes:FILM.scenes.map(({start,end})=>({start,end}))}));
  assert.equal(data.width,1920);assert.equal(data.height,1080);
  assert.equal(data.scenes[0].start,0);assert.equal(data.scenes.at(-1).end,75);
  assert(data.scenes.every((s,i)=>s.end>s.start&&(!i||s.start===data.scenes[i-1].end)),'Scenes must be contiguous');
  console.log('PASS: local fonts,1920×1080 canvas, contiguous0–75s timeline');

  await page.locator('#play').click();
  await page.waitForFunction(()=>Number(document.querySelector('#seek').value)>=5);
  assert.equal(await page.locator('#play').innerText(),'PAUSE');
  await page.locator('#play').click();
  await page.evaluate(()=>{const slider=document.querySelector('#seek');slider.value='2100';slider.dispatchEvent(new Event('input'))});
  await page.waitForFunction(()=>document.querySelector('#time').textContent.startsWith('01:10'));
  assert.equal(await page.locator('#seek').getAttribute('max'),'2249');
  console.log('PASS: playback advances; frame2100 scrubs to01:10');

  await page.locator('summary').click();
  const original=await page.locator('#config').inputValue();
  const changed=JSON.parse(original);changed.colors.lime='#AAF500';
  await page.locator('#config').fill(JSON.stringify(changed));await page.locator('#apply').click();
  assert.equal(await page.evaluate(()=>FILM.colors.lime),'#AAF500');
  assert.match(await page.locator('#message').innerText(),/Applied/);
  console.log('PASS: configuration editor applies palette changes');

  changed.media.product='assets/missing-smoke-test-product.mp4';
  await page.locator('#config').fill(JSON.stringify(changed));await page.locator('#apply').click();
  await page.waitForFunction(()=>document.querySelector('#assetError').textContent.includes('Product clip failed to load'));
  await page.locator('#config').fill(original);await page.locator('#apply').click();
  assert.deepEqual(errors,[],'Preview must have no uncaught JavaScript errors');
  console.log('PASS: missing product asset produces a visible error; no uncaught JavaScript errors');

  if(process.argv.includes('--media')){
   const file=path.join(root,'output/final-final-studio.mp4');
   assert(fs.existsSync(file),'MP4 does not exist; run npm run render first');
   const probe=JSON.parse(execFileSync('ffprobe',['-v','error','-show_format','-show_streams','-of','json',file],{encoding:'utf8'}));
   const video=probe.streams.find(s=>s.codec_type==='video'),audio=probe.streams.find(s=>s.codec_type==='audio');
   assert(video,'MP4 must contain video');assert(audio,'MP4 must contain audio');
   assert.equal(video.width,1920);assert.equal(video.height,1080);
   assert.equal(video.codec_name,'h264');assert.equal(video.avg_frame_rate,'30/1');
   assert.equal(Number(video.nb_frames),2250);assert(Math.abs(Number(video.duration)-75)<.001);
   assert(Math.abs(Number(probe.format.duration)-75)<.05);assert.equal(audio.codec_name,'aac');
   console.log('PASS: MP4 is H.264/AAC,1920×1080,30 fps,2250 frames,75 seconds');
  }
  console.log('All requested smoke checks passed.');
 }finally{
  if(browser)await browser.close();
  await new Promise(resolve=>server.close(resolve));
 }
})().catch(error=>{console.error(error);process.exitCode=1});
