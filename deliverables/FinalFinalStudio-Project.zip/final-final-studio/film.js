/* All artwork is drawn as editable vector primitives and live type.
   Timeline, palette, copy and paths: config.js. No rasterized title cards. */
(()=>{
const canvas=document.getElementById('film'),g=canvas.getContext('2d',{alpha:false});
const W=1920,H=1080;let video=null,videoError=null;
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const ease=v=>1-Math.pow(1-clamp(v),4);
const io=v=>(v=clamp(v))<.5?8*v*v*v*v:1-Math.pow(-2*v+2,4)/2;
const enter=(u,delay=0,d=.55)=>ease((u-delay)/d);
const lerp=(a,b,p)=>a+(b-a)*p;
function rect(x,y,w,h,c){g.fillStyle=c;g.fillRect(x,y,w,h)}
function line(x,y,x2,y2,c,w=2){g.strokeStyle=c;g.lineWidth=w;g.beginPath();g.moveTo(x,y);g.lineTo(x2,y2);g.stroke()}
function circle(x,y,r,c,stroke=false,w=2){g.beginPath();g.arc(x,y,r,0,Math.PI*2);g.lineWidth=w;if(stroke){g.strokeStyle=c;g.stroke()}else{g.fillStyle=c;g.fill()}}
function text(s,x,y,size=30,color=FILM.colors.white,opts={}){g.save();g.fillStyle=color;g.font=`${size}px ${opts.mono?'Mono':'Display'}`;g.textBaseline='alphabetic';if(opts.align)g.textAlign=opts.align;if(opts.alpha!==undefined)g.globalAlpha=opts.alpha;let width=g.measureText(s).width;let sx=opts.width?Math.min(1,opts.width/width):1;g.translate(x,y);g.scale(sx,1);g.fillText(s,0,0);g.restore()}
function tracked(s,x,y,size,color,spacing=4){g.save();g.fillStyle=color;g.font=`${size}px Mono`;let px=x;for(const c of s){g.fillText(c,px,y);px+=g.measureText(c).width+spacing}g.restore()}
function headline(s,x,y,size,color,u,opts={}){const ls=s.split('\n');ls.forEach((l,i)=>{let p=enter(u,i*.095);g.save();g.beginPath();g.rect(x-4,y-size+i*size*.98-5,opts.width||1730,size*1.06);g.clip();text(l,x,y+i*size*.98+(1-p)*size*1.2,size,color,opts);g.restore()})}
function arrow(x,y,size,color,rot=0){g.save();g.translate(x,y);g.rotate(rot);line(-size*.6,0,size*.6,0,color,size*.075);line(size*.1,-size*.5,size*.6,0,color,size*.075);line(size*.1,size*.5,size*.6,0,color,size*.075);g.restore()}
function plus(x,y,s,c){line(x-s,y,x+s,y,c,2);line(x,y-s,x,y+s,c,2)}
function label(s,x,y,ink){tracked(s,x,y,19,ink,2)}
function footer(t,ink,muted){line(100,981,1820,981,muted,1);text(FILM.copy.footerBrand,100,1020,18,ink,{mono:true});text(FILM.copy.footerEdition,960,1020,18,ink,{mono:true,align:'center'});let f=Math.floor(t*30);text(`${String(Math.floor(f/1800)).padStart(2,'0')}:${String(Math.floor(f/30)%60).padStart(2,'0')}:${String(f%30).padStart(2,'0')}  /  01:15:00`,1820,1020,18,ink,{mono:true,align:'right'})}
function chrome(s,t,ink,accent){label(s.note,100,107,ink);rect(1768,82,52,26,accent);line(1782,89,1790,100,ink,2);line(1790,100,1806,85,ink,2)}
function smallTag(s,x,y,bg,ink){g.font='18px Mono';const w=g.measureText(s).width+32;rect(x,y-25,w,38,bg);text(s,x+16,y,18,ink,{mono:true})}
function mask(x,y,w,h,fn){g.save();g.beginPath();g.rect(x,y,w,h);g.clip();fn();g.restore()}
function ring(x,y,r,c,u){g.save();g.translate(x,y);g.rotate(u*.15);g.scale(1,.35);g.lineWidth=14;g.strokeStyle=c;g.beginPath();g.arc(0,0,r,0,Math.PI*2);g.stroke();g.restore()}
function ruler(x,y,w,c){line(x,y,x+w,y,c,1);for(let i=0;i<=20;i++){let xx=x+w*i/20;line(xx,y,xx,y+(i%5===0?18:8),c,1)}}
function timeline(x,y,w,u,C){rect(x,y,w,156,'#232323');ruler(x+20,y+12,w-40,'#77776F');const tracks=[[FILM.copy.trackNames[0],C.white],[FILM.copy.trackNames[1],C.lime]];tracks.forEach(([n,c],i)=>{text(n,x+20,y+63+i*58,15,C.white,{mono:true});const widths=i?[.18,.25,.16,.23]:[.3,.14,.3,.08];let xx=x+80;for(let k=0;k<4;k++){let ww=(w-130)*widths[k];rect(xx,y+39+i*58,ww,39,c);if(!i){g.strokeStyle='#111';g.lineWidth=2;g.beginPath();for(let z=0;z<ww;z+=4){const v=7+Math.sin(z*.6)*5+Math.cos(z*.21+k)*5;g.moveTo(xx+z,y+58-v);g.lineTo(xx+z,y+58+v)}g.stroke()}else text(FILM.copy.editTakes[k],xx+8,y+65+i*58,13,C.black,{mono:true});xx+=ww+8;}});let px=x+80+((u*.11)%1)*(w-110);line(px,y+4,px,y+150,C.lime,3);g.fillStyle=C.lime;g.beginPath();g.moveTo(px-8,y);g.lineTo(px+8,y);g.lineTo(px,y+13);g.fill()}
function object(x,y,w,h,t,C,opts={}){
 mask(x,y,w,h,()=>{
 let bg=opts.light?C.white:C.lime;rect(x,y,w,h,bg);
 g.save();g.globalAlpha=.13;for(let i=-3;i<12;i++){g.save();g.translate(x+w*.5,y+h*.5);g.rotate(-.5);rect(i*w*.14+(t*12)%Math.max(1,w*.14),-h*2,2,h*4,C.black);g.restore()}g.restore();
 let cx=x+w*.5,cy=y+h*.48;ring(cx,cy+h*.13,Math.min(w,h)*.4,C.black,t);
 if(video&&video.readyState>=2){const r=Math.max(w/video.videoWidth,h/video.videoHeight),vw=video.videoWidth*r,vh=video.videoHeight*r;g.drawImage(video,x+(w-vw)/2,y+(h-vh)/2,vw,vh)}else{
 const scale=Math.min(w/480,h/540);g.save();g.translate(cx,cy+Math.sin(t*1.6)*h*.025);g.rotate(-.12+Math.sin(t*.55)*.11);g.scale(scale,scale);
 // An intentionally unbranded, stylised product stand-in, never represented as supplied footage.
 g.save();g.translate(25,232);g.scale(1,.17);circle(0,0,143,'rgba(17,17,17,.18)');g.restore();
 const grd=g.createLinearGradient(-110,0,110,0);grd.addColorStop(0,'#44443E');grd.addColorStop(.17,'#F5F5F0');grd.addColorStop(.45,'#CCCCBF');grd.addColorStop(.75,'#F5F5F0');grd.addColorStop(1,'#77776F');
 g.fillStyle=grd;g.beginPath();g.roundRect(-107,-188,214,388,30);g.fill();g.fillStyle=C.black;g.fillRect(-111,-145,222,266);
 g.fillStyle='#D0D0C4';g.beginPath();g.ellipse(0,-180,96,20,0,0,Math.PI*2);g.fill();g.strokeStyle='#77776F';g.lineWidth=3;g.stroke();g.fillStyle='#88887F';g.beginPath();g.ellipse(0,-179,32,9,-.3,0,Math.PI*2);g.fill();
 text(FILM.copy.sampleWords[0],-86,-50,48,C.white,{width:174});text(FILM.copy.sampleWords[1],-86,0,48,C.white);text(FILM.copy.sampleWords[2],-86,50,48,C.lime,{width:174});line(-83,77,83,77,C.lime,2);text(FILM.copy.sampleCode,-83,103,13,C.white,{mono:true});g.restore();}
 });
}
function concept(x,y,ink){text(FILM.copy.conceptLabel+' / '+(video&&video.readyState>=2?FILM.copy.providedLabel:FILM.copy.placeholderLabel),x,y,14,ink,{mono:true})}
window.loadMedia=()=>{videoError=null;if(FILM.media.product){video=document.createElement('video');video.src=FILM.media.product;video.muted=true;video.preload='auto';video.loop=true;video.playsInline=true;video.onerror=()=>videoError='Product clip failed to load: '+FILM.media.product;video.load()}else video=null};window.loadMedia();
window.getMediaError=()=>videoError;
window.previewFrame=t=>{if(video&&video.readyState>=1&&!video.seeking){const target=t%video.duration;if(Math.abs(video.currentTime-target)>.08)video.currentTime=target;}window.drawFrame(t)};
window.prepareFrame=async t=>{if(video){if(videoError)throw Error(videoError);if(video.readyState<1)await new Promise((resolve,reject)=>{video.addEventListener('loadedmetadata',resolve,{once:true});video.addEventListener('error',()=>reject(Error('Product video unavailable')),{once:true})});const target=t%video.duration;if(Math.abs(video.currentTime-target)>.0001){await new Promise((resolve,reject)=>{video.addEventListener('seeked',resolve,{once:true});video.addEventListener('error',reject,{once:true});video.currentTime=target})}}window.drawFrame(t)};
window.drawFrame=t=>{
 const C=FILM.colors;let s=FILM.scenes.find(v=>t>=v.start&&t<v.end)||FILM.scenes[FILM.scenes.length-1],u=t-s.start,d=s.end-s.start;
 let light=['request','pause','inputs','ratios','services','rename'].includes(s.type),lime=['rush','step'].includes(s.type)&&s.headline!=='REVIEW.';let bg=lime?C.lime:light?C.white:C.black,ink=lime||light?C.black:C.white,accent=lime?C.black:C.lime;
 rect(0,0,W,H,bg);chrome(s,t,ink,accent);
 switch(s.type){
 case 'request':{
 headline(s.headline,100,366,174,ink,u,{width:1130});text(s.sub,104,670,27,ink,{mono:true});
 let p=enter(u,.15);g.save();g.translate((1-p)*500,0);rect(1395,224,425,569,C.black);label(FILM.copy.incoming,1430,271,C.lime);line(1430,300,1785,300,'#555',1);text(FILM.copy.requestCounter,1430,506,190,C.white,{width:340});smallTag(FILM.copy.requestReceived,1430,739,C.lime,C.black);g.restore();
 line(100,816,1820,816,C.black,2);arrow(1747,877,87,C.black);label(FILM.copy.requestFooter,100,887,ink);break;}
 case 'stack':{
 headline(s.headline,100,362,151,ink,u,{width:1135});text(s.sub,104,652,26,ink,{mono:true});
 for(let i=0;i<3;i++){const p=enter(u,.12+i*.16);g.save();g.translate((1-p)*500,0);let x=1290+i*72,y=273-i*36;rect(x,y,335,482,i===2?C.lime:'#343434');text(FILM.copy.stackRatios[i],x+22,y+56,30,i===2?C.black:C.white,{mono:true});line(x+22,y+75,x+312,y+75,i===2?C.black:'#666',1);text(FILM.copy.stackIncrement,x+22,y+342,128,i===2?C.black:C.white);g.restore()}
 smallTag(FILM.copy.stackBadge,100,855,C.lime,C.black);break;}
 case 'deadline':{
 headline(s.headline,100,364,155,ink,u,{width:1210});text(s.sub,104,655,26,ink,{mono:true});let p=enter(u,.25);rect(1420,225,400,510,C.white);text(FILM.copy.captionsIcon,1450,407,149,C.black,{width:340});line(1450,450,1790,450,C.black,2);for(let i=0;i<3;i++)rect(1450,493+i*42,(290-i*52)*p,20,i===0?C.lime:C.black);
 for(let i=0;i<3;i++){let xx=100+i*570;rect(xx,792,535,93,i===2?C.lime:'#2A2A2A');text(FILM.copy.requestAdds[i],xx+24,852,29,i===2?C.black:C.white,{mono:true})}break;}
 case 'rush':{
 headline(s.headline,100,398,191,ink,u,{width:1600});text(s.sub,104,744,29,ink,{mono:true});
 let px=100+1620*enter(u,.3,1.5);line(100,851,1820,851,C.black,3);rect(px,832,100,38,C.black);label(FILM.copy.rushPriority,100,922,ink);text('↗',1814,745,140,ink,{align:'right'});break;}
 case 'pause':{
 const p=enter(u);text(s.headline,960,551,190,ink,{align:'center',width:1680});rect(100,778,1720*p,6,C.black);text(s.sub,960,676,30,ink,{mono:true,align:'center'});break;}
 case 'brand':{
 g.save();g.translate(0,(1-enter(u))*160);text(s.headline.split('\n')[0],90,430,325,C.white,{width:1320});text(s.headline.split('\n')[1]||'',90,737,325,C.lime,{width:1320});g.restore();
 const p=enter(u,.25);g.save();g.translate(1580,479);g.rotate((1-p)*Math.PI*.5);rect(-182,-182,364,364,C.lime);arrow(0,0,220,C.black,-Math.PI/4);g.restore();
 tracked(s.sub,112,855,41,C.white,20);label(FILM.copy.brandServices,100,930,C.white);break;}
 case 'inputs':{
 headline(s.headline,100,320,122,ink,u,{width:1630});const names=FILM.copy.inputNames;const notes=FILM.copy.inputNotes;
 for(let i=0;i<3;i++){let p=enter(u,.2+i*.18);let x=100+i*580,y=540+(1-p)*130;g.save();g.globalAlpha=p;rect(x,y,555,339,i===1?C.lime:C.black);text('0'+(i+1),x+27,y+52,23,i===1?C.black:C.lime,{mono:true});text(names[i],x+27,y+164,39,i===1?C.black:C.white,{width:505});text(notes[i],x+27,y+220,19,i===1?C.black:C.white,{mono:true,width:505});arrow(x+480,y+287,46,i===1?C.black:C.lime);g.restore()}break;}
 case 'edit':{
 headline(s.headline,100,354,150,ink,u,{width:850});text(s.sub,104,641,24,ink,{mono:true});smallTag(FILM.copy.editBadge,100,746,C.lime,C.black);
 object(1030,180,790,578,u,C);concept(1030,790,C.white);timeline(100,823,1720,u,C);break;}
 case 'captions':{
 headline(s.headline,100,324,118,ink,u,{width:990});text(s.sub,104,552,25,ink,{mono:true});
 const words=FILM.copy.sampleWords;for(let i=0;i<3;i++){const hit=Math.floor(u*1.25)%3===i;const x=100+[0,262,394][i];rect(x,660,[240,110,303][i],102,hit?C.lime:'#292929');text(words[i],x+15,735,67,hit?C.black:C.white,{width:[210,82,272][i]})}
 object(1190,182,630,673,u,C,{light:true});concept(1190,889,C.white);label(FILM.copy.captionTiming,100,851,C.white);line(100,877,1030,877,'#666',2);let xx=100+(u/d)*930;rect(xx,866,10,23,C.lime);break;}
 case 'ratios':{
 headline(s.headline,100,291,106,ink,u,{width:1720});
 const frames=[{x:100,y:466,w:710,h:400,ratio:FILM.copy.stackRatios[0]},{x:856,y:466,w:400,h:400,ratio:FILM.copy.stackRatios[1]},{x:1390,y:366,w:282,h:500,ratio:FILM.copy.stackRatios[2]}];
 frames.forEach((f,i)=>{g.save();let p=enter(u,.18+i*.13);g.globalAlpha=p;g.translate(0,(1-p)*75);object(f.x,f.y,f.w,f.h,u,C);text(f.ratio,f.x,f.y-20,24,ink,{mono:true});g.strokeStyle=ink;g.lineWidth=2;g.strokeRect(f.x,f.y,f.w,f.h);for(const [dx,dy] of [[0,0],[f.w,0],[0,f.h],[f.w,f.h]])rect(f.x+dx-5,f.y+dy-5,10,10,C.black);g.restore()});concept(100,927,C.black);break;}
 case 'graphics':{
 headline(s.headline,100,310,116,ink,u,{width:1720});
 const p=enter(u,.25);object(100,521,550,360,u,C);rect(680,521,550,360,C.white);mask(680,521,550,360,()=>{text(FILM.copy.sampleWords[0],705,654,106,C.black,{width:500});text(FILM.copy.sampleWords.slice(1).join(' '),705,758,106,C.black,{width:500});arrow(1140,823,64,C.black,-Math.PI/4)});rect(1260,521,560,360,C.lime);ring(1540,700,185,C.black,u);text(FILM.copy.sampleWords[2],1300,735,95,C.black,{width:475});
 [100,680,1260].forEach((x,i)=>{rect(x,487,535*p,3,C.lime);text(FILM.copy.matchingLabels[i],x,466,20,C.white,{mono:true})});concept(100,929,C.white);break;}
 case 'campaign':{
 headline(s.headline,100,334,160,ink,u,{width:830});text(s.sub,100,650,23,C.white,{mono:true,width:840});
 object(1000,197,540,665,u,C);rect(1448,586,372,282,C.white);text(FILM.copy.sampleWords[0],1470,680,59,C.black);text(FILM.copy.sampleWords.slice(1).join(' '),1470,750,59,C.black,{width:325});smallTag(FILM.copy.campaignBadge,100,805,C.lime,C.black);concept(1000,916,C.white);break;}
 case 'services':{
 headline(s.headline,100,285,111,ink,u,{width:1650});
 FILM.services.forEach(([name,desc],i)=>{let y=493+i*142;const p=enter(u,.2+i*.15);g.save();g.globalAlpha=p;g.translate((1-p)*140,0);line(100,y-31,1820,y-31,C.black,2);text('0'+(i+1),100,y+41,24,ink,{mono:true});text(name,218,y+42,58,ink,{width:1480});text(desc,220,y+93,23,ink,{mono:true});arrow(1765,y+34,62,C.black,-Math.PI/4);g.restore()});break;}
 case 'step':{
 let n=s.note.slice(0,2);text(n,100,336,200,ink,{alpha:.15});headline(s.headline,100,658,207,ink,u,{width:1630});text(s.sub,106,788,28,ink,{mono:true});
 let p=enter(u,.15);g.save();g.translate(1700,290);g.rotate((1-p)*Math.PI/2);circle(0,0,105,ink,true,3);arrow(0,0,105,ink,-Math.PI/4);g.restore();
 for(let i=0;i<3;i++)rect(100+i*580,915,550,7,i<Number(n)?ink:(lime?'#95BF00':'#444'));break;}
 case 'tagline':{
 const ls=s.headline.split('\n');ls.forEach((l,i)=>{const p=enter(u,i*.48,.6);g.save();mask(100,173+i*220,1720,219,()=>text(l,100+(1-p)*170,354+i*220,187,i===2?C.lime:C.white,{width:1660,alpha:p}));g.restore()});label(FILM.copy.taglineFoot,106,925,C.white);break;}
 case 'rename':{
 label(FILM.copy.renameExport,100,265,ink);line(100,300,1820,300,ink,2);rect(100,374,1720,310,C.black);let changed=u>=1.0;const value=changed?s.sub:s.headline;text(value,160,569,changed?115:144,C.white,{mono:true,width:1550});
 if(changed){let p=enter(u,1,.3);rect(160,624,1600*p,5,C.lime);smallTag(FILM.copy.renameStatus,100,804,C.lime,C.black)}else{text(FILM.copy.renamePending,100,804,26,ink,{mono:true})}arrow(1760,804,64,C.black);break;}
 case 'end':{
 // Final card settles in 0.55s and remains readable for the rest of the six-second hold.
 g.save();g.translate((1-enter(u))*-180,0);text(s.headline.split('\n')[0],96,396,280,C.white,{width:1220});text(s.headline.split('\n')[1]||'',96,658,280,C.lime,{width:1220});tracked(FILM.copy.studio,113,749,32,C.white,14);g.restore();
 let p=enter(u,.15);g.save();g.translate(1592,442);g.rotate((1-p)*-.4);rect(-207,-207,414,414,C.lime);arrow(0,0,246,C.black,-Math.PI/4);g.restore();
 line(100,810,1820,810,'#68685E',1);text(s.sub,100,914,65,C.white,{width:1580});arrow(1764,890,76,C.lime,-Math.PI/4);break;}
 }
 footer(t,ink,lime?'#85A800':light?'#BBBBB2':'#44443E');
 // Permanent discrete progress cue, editorial rather than flashing.
 rect(0,1074,1920*clamp(t/75),6,lime?C.black:C.lime);
};
})();
